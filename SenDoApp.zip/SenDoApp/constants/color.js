const color = {
    darkPink : '#e91e63'
}

export default color;