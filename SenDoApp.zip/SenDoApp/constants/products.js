const data = {
    title: 'Sản phẩm cho bạn',
     items : [
        {
            id: 1,
            name: 'ĐỒNG HỒ NAM',
            img: 'https://media3.scdn.vn/img3/2019/5_4/SPK8ob_simg_b5529c_250x250_maxb.jpg',
            url: 'https://www.sendo.vn/dong-ho-nam-contena-6478-thoi-trang-chinh-hang-dtt-passq-17869445.html?source_block_id=rec_may_like&source_page_id=home'
         },
         {
            id: 2,
            name: 'KEM ĐÁNH RĂNG',
            img: 'https://media3.scdn.vn/img3/2019/4_1/EgtekE_simg_b5529c_250x250_maxb.jpg',
            url: 'https://www.sendo.vn/tang-4-ban-chai-3-tuyp-kem-danh-rang-chong-e-buot-thai-lan-17118426.html?source_block_id=rec_may_like&source_page_id=home'
         },
         {
            id: 3,
            name: 'SRM TRÀ XANH',
            img: 'https://media3.scdn.vn/img3/2019/4_25/8db02U_simg_b5529c_250x250_maxb.jpg',
            url: 'https://www.sendo.vn/sua-rua-mat-tra-xanh-sach-nhon-trang-da-150ml-han-quoc-17713367.html?source_block_id=rec_may_like&source_page_id=home'
         },
         {
            id: 4,
            name: 'GỌNG KÍNH ACCEDE',
            img: 'https://media3.scdn.vn/img3/2019/7_16/ucKOsa_simg_b5529c_250x250_maxb.jpg',
            url: 'https://www.sendo.vn/gong-kinh-chinh-hang-accede-sonata-r544-nhieu-mau-19952489.html?source_block_id=rec_may_like&source_page_id=home'
         },
         {
            id: 5,
            name: 'DÉP KẸP NAM',
            img: 'https://media3.scdn.vn/img3/2019/7_24/vuXo37_simg_b5529c_250x250_maxb.jpg',
            url: 'https://www.sendo.vn/sieu-sale-dep-kep-nam-doc-quyen-di-em-chan-20190051.html?source_block_id=rec_may_like&source_page_id=home'
         },
         {
            id: 6,
            name: 'DẦU ĂN CÁI LÂN',
            img: 'https://media3.scdn.vn/img3/2019/9_6/3M448d_simg_b5529c_250x250_maxb.jpg',
            url: 'https://www.sendo.vn/dau-an-cai-lan-5-lit-21528837.html?source_block_id=rec_may_like&source_page_id=home'
         },
         {
            id: 7,
            name: 'NÓN KẾT SƠN LOGO',
            img: 'https://media3.scdn.vn/img3/2019/5_13/MqQhvm_simg_b5529c_250x250_maxb.png',
            url: 'https://www.sendo.vn/sale-cuc-lon-non-ket-son-logo-s-da-full-tem-7-mau-non-son-18526192.html?source_block_id=rec_may_like&source_page_id=home'
         },
         {
            id: 8,
            name: 'ĐỒNG HỒ NỮ JAPAN',
            img: 'https://media3.scdn.vn/img3/2019/4_11/Yy03Cj_simg_b5529c_250x250_maxb.jpg',
            url: 'https://www.sendo.vn/duoc-xem-hang-dong-ho-nu-den-tu-japan-sang-trong-bao-hanh-1-nam-17376008.html?source_block_id=rec_may_like&source_page_id=home'
         },
         {
            id: 9,
            name: 'KÍNH MÁT ABSENT',
            img: 'https://media3.scdn.vn/img2/2018/10_4/x8bPLU_simg_b5529c_250x250_maxb.jpg',
            url: 'https://www.sendo.vn/kinh-mat-absent-gong-vang-cuc-dep-12072896.html?source_block_id=rec_may_like&source_page_id=home'
         }, {
            id: 10,
            name: 'SIM ƯU ĐÃI',
            img: 'https://media3.scdn.vn/img3/2019/6_21/sJwkiJ_simg_b5529c_250x250_maxb.jpg',
            url: 'https://www.sendo.vn/sale-1-ngay-sim-uu-dai-vietell-tang-dien-thoai-1280-19346087.html?source_block_id=rec_may_like&source_page_id=home'
         }

     ]
}

export default data;