const data = {
    title : 'Xu hướng tìm kiếm',
    items : [
        {
            id: 1,
            name: '#túi xách nữ',
            img: 'https://media3.scdn.vn/img3/2019/3_27/aVDvsG_simg_3a7818_100x100_maxb.jpg',
            url: 'https://www.sendo.vn/tui-xach-nu'
    
        },
    
        {
            id: 2,
            name: '#đầm dạ hội',
            img: 'https://media3.scdn.vn/img2/2018/11_17/g3n6QZ_simg_3a7818_100x100_maxb.jpg',
            url: 'https://www.sendo.vn/dam-da-hoi'
    
        },
    
        {
            id: 3,
            name: '#kem dưỡng trăng da',
            img: 'http://media3.scdn.vn/img3/2019/4_19/6KT9kW_simg_3a7818_100x100_maxb.jpg',
            url: 'https://www.sendo.vn/kem-duong-trang-da'
    
        },
    
        {
            id: 4,
            name: '#điện thoại cũ',
            img: "https://media3.scdn.vn/img2/2018/7_25/LyY4am_simg_3a7818_100x100_maxb.png",
            url: 'https://www.sendo.vn/dien-thoai-cu'
    
        },
    
        {
            id: 5,
            name: '#ghế câu cá',
            img: "https://media3.scdn.vn/img3/2019/3_14/68JXho_simg_3a7818_100x100_maxb.jpg",
            url: 'https://www.sendo.vn/ghe-cau-ca'
    
        },
    
        {
            id: 6,
            name: '#giày búp bê',
            img: 'https://media3.scdn.vn/img3/2019/4_1/w9vVrP_simg_3a7818_100x100_maxb.jpg',
            url: 'https://www.sendo.vn/giay-bup-be'
    
        },
    
        {
            id: 7,
            name: '#chăn',
            img: 'https://media3.scdn.vn/img3/2019/3_29/qjHOOW_simg_3a7818_100x100_maxb.jpg',
            url: 'https://www.sendo.vn/chan'
    
        },
    
        {
            id: 8,
            name: '#mô hình one piece',
            img: 'https://media3.scdn.vn/img2/2017/9_2/sYOpnd_simg_3a7818_100x100_maxb.jpg',
            url: 'https://www.sendo.vn/mo-hinh-one-piece'
        },
    
        {
            id: 9,
            name: '#áo thun nữ',
            img: 'https://media3.scdn.vn/img3/2018/12_19/qKhIxM_simg_3a7818_100x100_maxb.jpg',
            url: 'https://www.sendo.vn/ao-thun-nu'
        },
    
        {
            id: 10,
            name: '#máy duỗi tóc',
            img: 'https://media3.scdn.vn/img3/2019/6_27/QYgRDy_simg_3a7818_100x100_maxb.jpg',
            url: 'https://www.sendo.vn/may-duoi-toc'
        }
    ]
}

export default data;